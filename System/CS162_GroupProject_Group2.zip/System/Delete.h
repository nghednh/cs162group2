#pragma once
#include "Structure.h"
void deleteClass(Class*& classs);
void deleteSchoolYear(SchoolYear*& year);
void deleteCourse(Course*& coursee);
void deleteStudent(Student*& stu);