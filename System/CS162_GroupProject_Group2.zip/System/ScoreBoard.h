#include "Structure.h"
string xiuupxiudown(float f);
void viewScoreBoard(SchoolYear* sy, int numSm, Student* stuInClass);
void viewScoreClass(SchoolYear* sy, int numSm, Class* cl);
void viewScoreboard(Course* course);
void viewScoreboardCourse(Course* course);